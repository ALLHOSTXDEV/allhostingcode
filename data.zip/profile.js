export const profile = {
  name: "ALLHOSTING",
  role: "small developer",
  roles: [
    "small developer",
    "whatsapp bot builder",
    "telegram bot builder",
    "rest api developer",
    "web developer",
    "automation enthusiast",
  ],
  tagline:
    "Saya adalah developer kecil yang senang membangun sesuatu dari ide sederhana menjadi project yang bisa digunakan.",
  about: [
    "Saya adalah developer kecil yang suka bereksperimen dan membangun berbagai project.",
    "Project yang pernah saya kerjakan antara lain WhatsApp Bot, Telegram Bot, REST API website, website penjualan, automation, dan hal-hal yang berhubungan dengan hosting atau VPS.",
    "Saya masih terus belajar, mencoba hal baru, dan membangun project satu per satu.",
  ],
  contact: {
    email: "allhosting3@gmail.com",
    tiktok: "@allhosting6",
    tiktokUrl: "https://www.tiktok.com/@allhosting6",
    instagram: "@fian_0802",
    instagramUrl: "https://www.instagram.com/fian_0802",
  },
  github: {
    username: null,
  },
  site: {
    url: "https://allhostingcode.vercel.com",
    title: "about me ( Allhosting )",
    description:
      "Portfolio pribadi allhosting — developer kecil yang membangun WhatsApp bot, Telegram bot, REST API, dan website satu project pada satu waktu.",
  },
};
